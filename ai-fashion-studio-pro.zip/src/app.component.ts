import { Component, signal, inject, computed, ViewChild, ElementRef, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GeminiService } from './services/gemini.service';

@Component({
  selector: 'app-root',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
  private geminiService = inject(GeminiService);

  @ViewChild('resultsContainer') resultsContainer!: ElementRef;

  // --- Theme State ---
  isDarkMode = signal<boolean>(true);

  // --- State Signals ---
  uploadedImage = signal<string | null>(null);
  uploadedImageMime = signal<string>('image/jpeg');
  
  // Selection State
  presentationType = signal<string>('female');
  modelHair = signal<string>('blonde');
  modelSkin = signal<string>('fair');
  modelBody = signal<string>('slim');
  studioTheme = signal<string>('studio_luxury');
  imageAspectRatio = signal<string>('3:4');
  
  // Process State
  isGenerating = signal<boolean>(false);
  generatedImages = signal<string[]>([]);
  errorMessage = signal<string | null>(null);

  toggleTheme() {
    this.isDarkMode.update(v => !v);
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      
      this.uploadedImageMime.set(file.type);

      reader.onload = (e) => {
        const result = e.target?.result as string;
        this.uploadedImage.set(result);
        this.generatedImages.set([]); // Reset previous results
        this.errorMessage.set(null);
      };
      
      reader.readAsDataURL(file);
    }
  }

  async generateShooting() {
    const image = this.uploadedImage();
    if (!image) {
      this.errorMessage.set("Please upload a garment image first.");
      return;
    }

    this.errorMessage.set(null);
    this.isGenerating.set(true);
    this.generatedImages.set([]);

    try {
      // Step 1: Prepare Image Data
      const base64Data = image.split(',')[1];
      const mimeType = this.uploadedImageMime();

      // Step 2: Construct the Context Prompt
      const fullPrompt = this.constructPrompt();
      console.log('Generating with prompt structure:', fullPrompt);

      // Step 3: Generate Images using Image Input + Prompt
      // The service will analyze the image and inject the description into [GARMENT_DESCRIPTION]
      const images = await this.geminiService.generatePhotoshoot(fullPrompt, this.imageAspectRatio(), base64Data, mimeType);
      this.generatedImages.set(images);

      // Step 4: Auto-scroll to results (UI Anchor)
      setTimeout(() => {
        if (this.resultsContainer?.nativeElement) {
          this.resultsContainer.nativeElement.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }, 100);

    } catch (error: any) {
      console.error("Full Error Object:", error);
      
      let message = "An error occurred during generation.";
      
      // Try to extract a meaningful message
      if (error?.message) {
        if (error.message.includes('429') || error.message.includes('quota') || error.message.includes('RESOURCE_EXHAUSTED')) {
          message = "High traffic detected (Quota Exceeded). The system retried but the servers are currently too busy. Please wait a minute and try again.";
        } else {
          message = error.message;
        }
      } else if (error?.statusText) {
        message = error.statusText;
      }
      
      this.errorMessage.set(message);
    } finally {
      this.isGenerating.set(false);
    }
  }

  constructPrompt(): string {
    const type = this.presentationType();
    const hair = this.modelHair();
    const skin = this.modelSkin();
    const body = this.modelBody();
    const theme = this.studioTheme();

    // 1. Model Definition
    let modelDesc = '';
    if (type === 'floating') {
      modelDesc = 'INVISIBLE GHOST MANNEQUIN. No human visible. The garment is 3D filled.';
    } else {
      let genderTerm = 'Professional Female Fashion Model';
      if (type === 'male') genderTerm = 'Professional Male Fashion Model';
      if (type === 'girl') genderTerm = 'Young Girl Model (Child fashion)';
      if (type === 'boy') genderTerm = 'Young Boy Model (Child fashion)';
      
      // Enforce full body metrics in the model description itself
      modelDesc = `${genderTerm}, ${skin} skin, ${body} build, ${hair} hair. Pose: Walking or standing confidently, Full Body View.`;
    }

    // 2. Theme & Lighting Definition
    let themeDesc = '';
    let lightDesc = '';
    switch (theme) {
      case 'tech': 
        themeDesc = 'Futuristic Set, Neon accents, Metallic surfaces, dark tech background.'; 
        lightDesc = 'Cyberpunk lighting, cool tones, sharp rim lighting.';
        break;
      case 'business': 
        themeDesc = 'Modern Skyscraper Office, sleek glass furniture, urban city view.'; 
        lightDesc = 'Bright, diffuse daylight, clean corporate aesthetic.';
        break;
      case 'fun': 
        themeDesc = 'Pop Art Studio, Solid vibrant colors, geometric props.'; 
        lightDesc = 'High-key lighting, hard shadows, energetic.';
        break;
      case 'minimalist': 
        themeDesc = 'Infinite White Cyclorama, Abstract architectural geometry.'; 
        lightDesc = 'Softbox lighting, diffuse shadows, clean and airy.';
        break;
      case 'dramatic': 
        themeDesc = 'Dark Studio, Textured slate background.'; 
        lightDesc = 'Chiaroscuro, deep shadows, spotlight focusing on garment texture.';
        break;
      case 'couture': 
        themeDesc = 'Luxury Fashion Runway, Gold details.'; 
        lightDesc = 'Spotlights, dramatic runway lighting.';
        break;
      case 'streetwear': 
        themeDesc = 'Urban Concrete Environment, Graffiti texture, City street.'; 
        lightDesc = 'Natural sunlight, golden hour.';
        break;
      case 'studio_luxury': 
      default:
        themeDesc = 'High-End Luxury Photo Studio, Neutral Grey textured backdrop.'; 
        lightDesc = 'Professional Studio Lighting, soft fill, revealing fabric details.';
    }

    // 3. Prompt Assembly 
    // Emphasize Full Body Framing explicitly in the prompt structure
    return `
      Professional fashion photography. Wide-Angle Full-Body Shot.
      Subject: A ${modelDesc}
      Attire: Wearing [GARMENT_DESCRIPTION].
      
      CRITICAL FRAMING INSTRUCTION:
      - SHOW THE ENTIRE MODEL FROM HEAD TO TOE.
      - SHOES MUST BE VISIBLE.
      - DO NOT CROP THE HEAD OR FEET.
      - Camera Distance: Far enough to capture the full silhouette.
      
      STYLING & INTEGRITY RULES:
      - The garment MUST be the absolute focus. The patterns and cut must match the description exactly.
      - DO NOT CHANGE THE LENGTH OF THE GARMENT.
      - If the garment is a dress or skirt, maintain its original hemline strictly.
      - If the garment is short (e.g. mini dress) and the model's legs need coverage for the look: Add fashion tights or simple trousers underneath. DO NOT lengthen the dress itself.
      
      Setting: ${themeDesc}
      Lighting: ${lightDesc}
      Style: 8k resolution, photorealistic, highly detailed fabric texture, sharp focus, magazine editorial quality.
    `;
  }

  downloadImage(base64: string, index: number) {
    const link = document.createElement('a');
    link.href = base64;
    link.download = `fashion-shoot-${index + 1}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  reset() {
    this.uploadedImage.set(null);
    this.generatedImages.set([]);
    this.errorMessage.set(null);
  }
}