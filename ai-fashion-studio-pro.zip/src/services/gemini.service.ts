import { Injectable } from '@angular/core';
import { GoogleGenAI } from '@google/genai';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Assuming process.env.API_KEY is available in the environment
    this.ai = new GoogleGenAI({ apiKey: process.env['API_KEY'] || '' });
  }

  async generatePhotoshoot(prompt: string, aspectRatio: string, imageBase64: string, mimeType: string): Promise<string[]> {
    return this.retryOperation(async () => {
      try {
        // Step 1: Use Gemini 2.5 Flash to describe the garment (Vision)
        // High-fidelity description focus for accurate recreation.
        const visionResponse = await this.ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: {
            parts: [
              { inlineData: { mimeType: mimeType, data: imageBase64 } },
              { text: "You are a fashion archivist. Analyze this garment image to create a reproduction prompt. Describe the garment in EXTREME detail. Focus on: 1. Exact Fabric Texture (e.g. washed denim, heavy cotton). 2. Precise Patterns & Graphics (describe every print, logo, and embroidery placement). 3. Structural Construction (neckline, hem, cuffs, fit). 4. Color Nuances. Output a dense, comma-separated visual description starting with the garment type (e.g. 'a heavy washed denim jacket with pink cherry blossom embroidery...')." }
            ]
          }
        });

        const garmentDescription = visionResponse.text || 'a stylish fashion garment';
        
        // Step 2: Integrate description into the main prompt
        let finalPrompt = prompt;
        if (finalPrompt.includes('[GARMENT_DESCRIPTION]')) {
          finalPrompt = finalPrompt.replace('[GARMENT_DESCRIPTION]', garmentDescription);
        } else {
          finalPrompt = `${prompt} The model is wearing ${garmentDescription}.`;
        }

        // Step 3: Generate the photoshoot image
        const response = await this.ai.models.generateImages({
          model: 'imagen-4.0-generate-001',
          prompt: finalPrompt,
          config: {
            numberOfImages: 1, 
            aspectRatio: aspectRatio,
            outputMimeType: 'image/jpeg'
          }
        });

        if (response.generatedImages) {
          return response.generatedImages.map(img => `data:image/jpeg;base64,${img.image.imageBytes}`);
        }
        return [];
      } catch (error) {
        console.error('Error generating photoshoot:', error);
        throw error;
      }
    });
  }

  /**
   * Retries an operation if a 429 (Quota Exceeded) error occurs.
   * Uses exponential backoff.
   */
  private async retryOperation<T>(operation: () => Promise<T>, retries = 3, delay = 2000): Promise<T> {
    try {
      return await operation();
    } catch (error: unknown) {
      // Check for common 429 indicators in the error object or message
      const err = error as any;
      const isQuotaError = 
        err?.status === 429 || 
        err?.code === 429 || 
        (err?.message && err.message.includes('429')) ||
        (err?.message && err.message.includes('quota')) ||
        (err?.message && err.message.includes('RESOURCE_EXHAUSTED'));

      if (isQuotaError && retries > 0) {
        console.warn(`Quota limit hit. Retrying in ${delay}ms... (${retries} attempts left)`);
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.retryOperation(operation, retries - 1, delay * 2);
      }
      
      throw error;
    }
  }
}